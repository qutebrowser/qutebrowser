(function() {
    const arg1 = '{{1}}';
    let reStr;
    if ( arg1 === '{{1}}' || arg1 === '' ) {
        reStr = '^';
    } else if ( arg1.startsWith('/') && arg1.endsWith('/') ) {
        reStr = arg1.slice(1, -1);
    } else {
        reStr = arg1.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    try {
        const re = new RegExp(reStr);
        if ( re.test(`${window.location.pathname}${window.location.search}`) ) {
            window.close();
        }
    } catch(ex) {
        console.log(ex);
    }
})();
