(function() {
    const arg1 = '{{1}}';
    let reStr;
    let subject = '';
    if ( arg1 === '{{1}}' || arg1 === '' ) {
        reStr = '^';
    } else if ( /^\/.*\/$/.test(arg1) ) {
        reStr = arg1.slice(1, -1);
        subject = window.location.href;
    } else {
        reStr = arg1.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        subject = `${window.location.pathname}${window.location.search}`;
    }
    try {
        const re = new RegExp(reStr);
        if ( re.test(subject) ) {
            window.close();
        }
    } catch(ex) {
        console.log(ex);
    }
})();
