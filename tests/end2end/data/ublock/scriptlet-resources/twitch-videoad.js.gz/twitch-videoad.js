(function() {
    if ( /(^|\.)twitch\.tv$/.test(document.location.hostname) === false ) { return; }
    window.fetch = new Proxy(window.fetch, {
        apply: function(target, thisArg, args) {
            const [ url, init ] = args;
            if (
                typeof url === 'string' &&
                url.includes('gql') &&
                init instanceof Object &&
                init.headers instanceof Object &&
                typeof init.body === 'string' &&
                init.body.includes('PlaybackAccessToken') &&
                init.body.includes('"isVod":true') === false
            ) {
                const { headers } = init;
                if ( typeof headers['X-Device-Id'] === 'string' ) {
                    headers['X-Device-Id'] = 'twitch-web-wall-mason';
                }
                if ( typeof headers['Device-ID'] === 'string' ) {
                    headers['Device-ID'] = 'twitch-web-wall-mason';
                }
            }
            return Reflect.apply(target, thisArg, args);
        }
    });
})();
