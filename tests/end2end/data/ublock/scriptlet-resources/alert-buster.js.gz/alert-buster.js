(function() {
    window.alert = new Proxy(window.alert, {
        apply: function(a) {
            console.info(a);
        },
    });
})();
